<?php
global $con;
$con = mysqli_connect("localhost","id12561718_davey","12345","id12561718_daveyal");
?>


